import logo from './logo.svg';
import './App.css';
import Acc from './accordion'
function App() {
  return (
    <div className="App">
      <Acc />
    </div>
  );
}

export default App;
